<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\Bank;

use Illuminate\Http\JsonResponse;
use Illuminate\Support\Facades\Auth;

class BankController extends Controller
{
    public function index(): JsonResponse
    {
        $banks = Bank::where('user_id', Auth::id())->get();

        return response()->json($banks, 200);
    }

    public function loadLenderBanks($lender_id): JsonResponse
    {
        $banks = Bank::where('user_id', $lender_id)->get();

        return response()->json($banks, 200);
    }
}
